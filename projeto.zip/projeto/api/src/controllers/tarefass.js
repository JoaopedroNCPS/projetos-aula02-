const con = require('../connect');

function create(req, res) {
    const { tarefa, data, progresso } = req.body;
    const sql = `INSERT INTO tarefas (tarefa, data, progresso) VALUES ('${tarefa}', '${data}', '${progresso}')`;
    con.query(sql, (error, result) => {
        if (error) {
            res.status(500).json('Erro ao cadastrar paciente');
        } else {
            res.status(201).json('paciente cadastrado com sucesso');
        }
    });
};

function read(req, res) {
    const sql = 'SELECT * FROM tarefas';
    con.query(sql, (error, result) => {
        if (error) {
            res.status(500).json('Erro ao ler o Progresso das Tarefas');
        } else {
            res.status(200).json(result);
        }
    });
}

function update(req, res) {
    const { id } = req.params;
    const { tarefa, data, progresso } = req.body;
    const sql = `UPDATE tarefas SET tarefa = '${tarefa}', data= '${data}', progresso = '${progresso}' WHERE tarefa_id = ${id}`;
    con.query(sql, (error, result) => {
        if (error) {
            res.status(500).json('Erro ao alterar a Tarefa');
        } else {
            res.status(202).json('Tarefa alterada com sucesso');
        }
    });
}

function del(req, res) {
    const { id } = req.params;
    const sql = `DELETE FROM tarefas WHERE tarefa_id = ${id}`;
    con.query(sql, (error, result) => {
        if (error) {
            res.status(500).json('Erro ao excluir a Tarefa');
        } else {
            res.status(204).json('Tarefa excluída');
        }
    });
}

module.exports = {
    create,
    read,
    update,
    del
}