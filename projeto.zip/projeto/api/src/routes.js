const express = require('express');

const routes = express.Router();

const Tarefa = require('./controllers/tarefass');

routes.get('/', (req, res)=>{
    res.send('API Respondendo!')
});

routes.post('/tarefas', Tarefa.create)
routes.get('/tarefas', Tarefa.read)
routes.put('/tarefas/:id', Tarefa.update)
routes.delete('/tarefas/:id', Tarefa.del)

module.exports = routes;