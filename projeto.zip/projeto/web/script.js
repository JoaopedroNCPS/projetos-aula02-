const tarefa = document.getElementById('Tarefa');
tarefa.addEventListener('submit', (event) => {
    event.preventDefault();
    const corpo = {
        tarefa: tarefa.tarefa.value,
        data: tarefa.data.value,
        progresso: tarefa.progresso.value
    }
    fetch('http://localhost:4000/tarefas', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(corpo)
    })
        .then(response => response.status)
        .then(status => {
            if (status === 201) {
                msg3('Tarefa Inserida');
            } else {
                msg3('Erro ao inserir');
            }
        });
});


fetch('http://localhost:4000/tarefas')
    .then(response => response.json())
    .then(tarefas => {
        const container = document.getElementById('tarefas-container');
        tarefas.forEach(tarefa => {
            const card = document.createElement('div');
            card.classList.add('tarefa-card');
            card.innerHTML = `
                <h3>${tarefa.tarefa}</h3>
                <p><strong>Data:</strong> ${new Date(tarefa.data).toLocaleDateString('pt-BR')}</p>
                <p><strong>Progresso:</strong> ${tarefa.progresso}%</p>
                <button onclick="alterar(this)">*</button>
                <button onclick="excluir(${tarefa.tarefa_id})">-</button>
            `;
            container.appendChild(card);
        });
    });

    function msg3 (mensagem){
        msg = document.getElementById('msg');
        msg.innerHTML = mensagem

        setTimeout(()  => {
            window.location.reload();
        }, 1500);
    }
